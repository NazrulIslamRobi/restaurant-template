<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Recipee</title>
  <link href='//fonts.googleapis.com/css?family=Source+Sans+Pro:400,400i,600,600i,700,700i|Montserrat:400,400i,700,700i'
    media='all' rel='stylesheet' type='text/css' />
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css" />
  <link rel="stylesheet" href="css/recipe.css">
</head>

<body>
  <!-- Outer Wrapper -->
  <div id='outer-wrapper'>
    <!-- Main Top Bar -->
    <div id='top-bar'>
      <div class='container row'>
        <div class='top-bar-nav section' id='top-bar-nav' name='Top Navigation'>
          <div class='widget LinkList' id='LinkList72'>
            <div class='widget-content'>
              <ul>
                <li><a href='/'>Home</a></li>
                <li><a href=''>About</a></li>
                <li><a href=''>Contact</a></li>
              </ul>
            </div>
          </div>
        </div>
        <!-- Top Social -->
        <div class='top-bar-social social section' id='top-bar-social' name='Social Top'>
          <div class='widget LinkList' id='LinkList73'>
            <div class='widget-content'>
              <ul>
                <li class='facebook'><a href='#' target='_blank' title='facebook'></a></li>
                <li class='twitter'><a href='#' target='_blank' title='twitter'></a></li>
                <li class='instagram'><a href='#' target='_blank' title='instagram'></a></li>
                <li class='pinterest'><a href='#' target='_blank' title='pinterest'></a></li>
                <li class='gplus'><a href='#' target='_blank' title='gplus'></a></li>
              </ul>
            </div>
          </div>
        </div>
      </div>
    </div>
    <!-- Header Wrapper -->
    <div id='header-wrap'>
      <div class='header-header'>
        <div class='container row'>
          <div class='header-logo section' id='header-logo' name='Header Logo'>
            <div class='widget Header' id='Header1'>
              <div class='header-widget'>
                <a class='header-image-wrapper' href='index.php'>
                  <img alt='Recipee' data-height='60' data-width='160' src='img/logo.png' />
                </a>
              </div>
            </div>
          </div>

        </div>
      </div>
      <div class="header-menu">
        <div class="mobile-menu">
          <ul id="main-menu-nav" role="menubar">
            <li><a href="index.php" role="menuitem">Home</a></li>
            <li class="has-sub"><a href="#" role="menuitem">Features</a>
              <ul class="sub-menu m-sub">
                <li class="has-sub"><a href="#" role="menuitem">Multi DropDown</a>
                  <ul class="sub-menu2 m-sub">
                    <li><a href="#" role="menuitem">DropDown 1</a></li>
                    <li><a href="#" role="menuitem">DropDown 2</a></li>
                    <li><a href="#" role="menuitem">DropDown 3</a></li>
                  </ul>
                  <div class="submenu-toggle"></div>
                </li>
                <li><a href="" role="menuitem">ShortCodes</a></li>
                <li><a href="" role="menuitem">SiteMap</a></li>
                <li><a href="" role="menuitem">Error Page</a>
                </li>
              </ul>
              <div class="submenu-toggle"></div>
            </li>
          </ul>
        </div>
        <div class="container row">
          <span class="slide-menu-toggle"></span>
          <div class="main-menu section" id="main-menu" name="Main Menu">
            <div class="LinkList show-menu widget" data-version="2" id="LinkList74">
              <ul id="main-menu-nav" role="menubar">
                <li><a href="index.php" role="menuitem">Home</a></li>
                <li class="has-sub"><a href="#" role="menuitem">Features</a>
                  <ul class="sub-menu m-sub">
                    <li class="has-sub"><a href="#" role="menuitem">Multi DropDown</a>
                      <ul class="sub-menu2 m-sub">
                        <li><a href="#" role="menuitem">DropDown 1</a></li>
                        <li><a href="#" role="menuitem">DropDown 2</a></li>
                        <li><a href="#" role="menuitem">DropDown 3</a></li>
                      </ul>
                    </li>
                    <li><a href="" role="menuitem">ShortCodes</a></li>
                    <li><a href="" role="menuitem">SiteMap</a></li>
                    <li><a href="" role="menuitem">Error Page</a></li>
                  </ul>
                </li>
                <li><a href="" role="menuitem">Download This Template</a></li>
              </ul>
            </div>
          </div>
          <div id="nav-search">
            <form action="" class="search-form" role="search">
              <input autocomplete="off" class="search-input" name="q" placeholder="Search this blog" type="search"
                value="">
              <span class="hide-search"></span>
            </form>
          </div>
          <span class="show-search"></span>
        </div>
      </div>
    </div>
    <div class='clearfix'></div>

    <!-- Content Wrapper -->
    <div class='row' id='content-wrapper'>
      <div class='container'>
        <!-- Main Wrapper -->
        <div id='main-wrapper'>
          <div class='main section' id='main'>
            <div class='widget Blog' id='Blog1'>
              <div class="blog-posts hfeed container item-post-wrap">
                <div class="blog-post hentry item-post">

                  <h1 class="post-title">
                    Frozen Blood and Sand Cocktail
                  </h1>
                  <div class="post-meta">
                    <span class="post-author"><a href="#" target="_blank" title="">No One</a></span>
                    <span class="post-date published" datetime="2016-03-17T00:20:00-07:00">March 17, 2016</span>
                  </div>
                  <div class="post-body post-content">
                    <img data-original-height="775" data-original-width="1068" src="img/article/1.jpg" alt="">
                    <br>
                    <div>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been
                      the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of
                      type and scrambled it to make a type specimen book <br><br>
                      <blockquote class="tr_bq">Lorem Ipsum has been the industry's standard dummy text ever since the
                        1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen
                        book.</blockquote><br>It was popularised in the 1960s with the release of Letraset sheets
                      containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus
                      PageMaker including versions of Lorem Ipsum.<br><br>
                      <ul>
                        <li>Lorem Ipsum has been the industry's</li>
                        <li>The generated Lorem Ipsum is therefore always</li>
                        <li>Making this the first true generator </li>
                      </ul>
                      <div><br>It is a long established fact that a reader will be distracted by the readable content of
                        a page when looking at its layout. The point of using Lorem Ipsum is that it has a more-or-less
                        normal distribution of letters, as opposed to using 'Content here, content here', making it look
                        like readable English. </div>
                      <div><br>It uses a dictionary of over 200 Latin words, combined with a handful of model sentence
                        structures, to generate Lorem Ipsum which looks reasonable. The generated Lorem Ipsum is
                        therefore always free from repetition, injected humour, or non-characteristic words
                        etc.<br><br>There are many variations of passages of Lorem Ipsum available, but the majority
                        have suffered alteration in some form, by injected humour, or randomised words which don't look
                        even slightly believable. If you are going to use a passage of Lorem Ipsum, you need to be sure
                        there isn't anything embarrassing hidden in the middle of text. </div>
                    </div>
                  </div>
                  <div class="post-footer">
                    <div class="post-labels">
                      <span>Tags</span>
                      <div class="label-head Label">
                        <a class="label-link" href="#" rel="tag">Food</a>
                      </div>
                    </div>
                    <div class="post-reactions">
                      <span>Reactions</span>
                      <div class="reactions-inner">

                      </div>
                    </div>
                    <div class="post-share">
                      <ul class="share-links social social-color">
                        <li class="facebook"><a class="facebook" href="https://www.facebook.com/sharer.php?u=#"
                            onclick="window.open(this.href, 'windowName', 'width=550, height=650, left=24, top=24, scrollbars, resizable'); return false;"
                            rel="nofollow"><span>Facebook</span></a></li>
                        <li class="twitter"><a class="twitter"
                            href="https://twitter.com/share?url=#&amp;text=Frozen Blood and Sand Cocktail"
                            onclick="window.open(this.href, 'windowName', 'width=550, height=450, left=24, top=24, scrollbars, resizable'); return false;"
                            rel="nofollow"><span>Twitter</span></a></li>

                        <li class="pinterest"><a class="pinterest"
                            href="https://www.pinterest.com/pin/create/button/?url=#&amp;media=#"
                            onclick="window.open(this.href, 'windowName', 'width=735, height=750, left=24, top=24, scrollbars, resizable'); return false;"
                            rel="nofollow"></a></li>
                        <li class="linkedin"><a class="linkedin" href="https://www.linkedin.com/shareArticle?url=#"
                            onclick="window.open(this.href, 'windowName', 'width=550, height=650, left=24, top=24, scrollbars, resizable'); return false;"
                            rel="nofollow"></a></li>
                        <li class="whatsapp whatsapp-desktop"><a class="whatsapp"
                            href="https://web.whatsapp.com/send?text=Frozen Blood and Sand Cocktail | #"
                            onclick="window.open(this.href, 'windowName', 'width=900, height=550, left=24, top=24, scrollbars, resizable'); return false;"
                            rel="nofollow"></a></li>
                        <li class="whatsapp whatsapp-mobile"><a class="whatsapp"
                            href="https://api.whatsapp.com/send?text=Frozen Blood and Sand Cocktail | #" rel="nofollow"
                            target="_blank"></a></li>
                        <li class="email"><a class="email"
                            href="mailto:?subject=Frozen Blood and Sand Cocktail&amp;body=#"
                            onclick="window.open(this.href, 'windowName', 'width=500, height=400, left=24, top=24, scrollbars, resizable'); return false;"
                            rel="nofollow"></a></li>
                      </ul>
                    </div>

                    <div id="related-wrap">
                      <div class="title-wrap">
                        <h3>You may like these posts</h3>
                      </div>
                      <div class="related-ready">
                        <ul class="related-posts">
                                                    <li class="related-item item-0">
                            <div class="post-image-wrap">
                              <a class="post-image-link" href="#">
                                <img class="post-thumb" alt="Frozen Blood and Sand Cocktail" src="img/article/1.jpg">
                              </a>
                              <span class="post-tag">Food</span>
                            </div>
                            <h2 class="post-title"><a href="#">Frozen
                                Blood and Sand Cocktail</a></h2>
                            <div class="post-meta"><span class="post-date">March 17, 2016</span></div>
                          </li>
                                                    <li class="related-item item-0">
                            <div class="post-image-wrap">
                              <a class="post-image-link" href="#">
                                <img class="post-thumb" alt="Frozen Blood and Sand Cocktail" src="img/article/1.jpg">
                              </a>
                              <span class="post-tag">Food</span>
                            </div>
                            <h2 class="post-title"><a href="#">Frozen
                                Blood and Sand Cocktail</a></h2>
                            <div class="post-meta"><span class="post-date">March 17, 2016</span></div>
                          </li>
                                                    <li class="related-item item-0">
                            <div class="post-image-wrap">
                              <a class="post-image-link" href="#">
                                <img class="post-thumb" alt="Frozen Blood and Sand Cocktail" src="img/article/1.jpg">
                              </a>
                              <span class="post-tag">Food</span>
                            </div>
                            <h2 class="post-title"><a href="#">Frozen
                                Blood and Sand Cocktail</a></h2>
                            <div class="post-meta"><span class="post-date">March 17, 2016</span></div>
                          </li>
                                                  </ul>
                      </div>
                    </div>
                  </div>
                </div>
                <div class="blog-post-comments comments-system-blogger" style="display: block;">

                  <div class="title-wrap comments-title">
                    <h3>Post a Comment</h3>
                  </div>
                  <section class="comments embed" data-num-comments="0" id="comments">
                    <a></a>
                    <h3 class="title">0
                      Comments</h3>
                    <div id="Blog1_comments-block-wrapper">
                    </div>
                    <div class="footer">
                      <div class="comment-form" id="comment-editor">



                      </div>
                    </div>
                  </section>
                </div>
              </div>
            </div>
          </div>
        </div>
        <!-- Sidebar Wrapper -->
        <div id='sidebar-wrapper'>
          <div class="theiaStickySidebar">

            <div class='sidebar section' id='social-widget' name='Social Widget'>
              <div class='widget LinkList' id='LinkList75'>
                <div class='widget-title'>
                  <h3 class='title'>
                    Social Plugin
                  </h3>
                </div>
                <div class='widget-content'>
                  <ul class='social-counter social social-color'>
                    <li class='facebook'><a href='http://fb.com/' target='_blank' title='facebook'></a></li>
                    <li class='twitter'><a href='#' target='_blank' title='twitter'></a></li>
                    <li class='instagram'><a href='#' target='_blank' title='instagram'></a></li>
                    <li class='youtube'><a href='#' target='_blank' title='youtube'></a></li>
                  </ul>
                </div>
              </div>
            </div>
            <div class='sidebar common-widget section' id='sidebar2'>
              <div class='widget PopularPosts' id='PopularPosts1'>
                <div class='widget-title'>
                  <h3 class='title'>
                    Popular Posts
                  </h3>
                </div>
                <div class='widget-content'>
                                    <div class='post'>
                    <div class='post-content'>
                      <a class='post-image-link' href='#'>
                        <img alt='Healthy Spinach Pasta With Exotic Vegetables' class='post-thumb'
                          src='img/article/1.jpg' />
                      </a>
                      <div class='post-info'>
                        <h2 class='post-title'>
                          <a href='#'>Healthy Spinach
                            Pasta With Exotic Vegetables</a>
                        </h2>
                        <div class='post-meta'>
                          <span class='post-date published' datetime='2016-08-23T15:00:00-07:00'>August 23, 2016</span>
                        </div>
                      </div>
                    </div>
                  </div>
                                    <div class='post'>
                    <div class='post-content'>
                      <a class='post-image-link' href='#'>
                        <img alt='Healthy Spinach Pasta With Exotic Vegetables' class='post-thumb'
                          src='img/article/1.jpg' />
                      </a>
                      <div class='post-info'>
                        <h2 class='post-title'>
                          <a href='#'>Healthy Spinach
                            Pasta With Exotic Vegetables</a>
                        </h2>
                        <div class='post-meta'>
                          <span class='post-date published' datetime='2016-08-23T15:00:00-07:00'>August 23, 2016</span>
                        </div>
                      </div>
                    </div>
                  </div>
                                    <div class='post'>
                    <div class='post-content'>
                      <a class='post-image-link' href='#'>
                        <img alt='Healthy Spinach Pasta With Exotic Vegetables' class='post-thumb'
                          src='img/article/1.jpg' />
                      </a>
                      <div class='post-info'>
                        <h2 class='post-title'>
                          <a href='#'>Healthy Spinach
                            Pasta With Exotic Vegetables</a>
                        </h2>
                        <div class='post-meta'>
                          <span class='post-date published' datetime='2016-08-23T15:00:00-07:00'>August 23, 2016</span>
                        </div>
                      </div>
                    </div>
                  </div>
                                  </div>
              </div>

              <div class='widget Label' id='Label3'>
                <div class='widget-title'>
                  <h3 class='title'>
                    Categories
                  </h3>
                </div>
                <div class='widget-content list-label'>
                  <ul>
                                        <li>
                      <a class='label-name' href='search.php'>
                        Business
                        <span class='label-count'>0</span>
                      </a>
                    </li>
                                        <li>
                      <a class='label-name' href='search.php'>
                        Business
                        <span class='label-count'>1</span>
                      </a>
                    </li>
                                        <li>
                      <a class='label-name' href='search.php'>
                        Business
                        <span class='label-count'>2</span>
                      </a>
                    </li>
                                        <li>
                      <a class='label-name' href='search.php'>
                        Business
                        <span class='label-count'>3</span>
                      </a>
                    </li>
                                      </ul>
                </div>
              </div>
              <div class='widget Label' id='Label4'>
                <div class='widget-title'>
                  <h3 class='title'>
                    Tags
                  </h3>
                </div>
                <div class='widget-content cloud-label'>
                  <ul>
                    <li>
                      <a class='label-name' href='search.php'>
                        Beauty
                      </a>
                    </li>
                    <li>
                      <a class='label-name' href='search.php'>
                        Business
                      </a>
                    </li>
                    <li>
                      <a class='label-name' href='search.php'>
                        Fashion
                      </a>
                    </li>
                    <li>
                      <a class='label-name' href='search.php'>
                        Learn
                      </a>
                    </li>
                    <li>
                      <a class='label-name' href='search.php'>
                        Music
                      </a>
                    </li>
                    <li>
                      <a class='label-name' href='search.php'>
                        Nature
                      </a>
                    </li>
                    <li>
                      <a class='label-name' href='search.php'>
                        People
                      </a>
                    </li>
                    <li>
                      <a class='label-name' href='search.php'>
                        Photography
                      </a>
                    </li>
                    <li>
                      <a class='label-name' href='search.php'>
                        Sports
                      </a>
                    </li>
                    <li>
                      <a class='label-name' href='search.php'>
                        Technology
                      </a>
                    </li>
                  </ul>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
    <div class='clearfix'></div>
    <!-- Footer Wrapper -->
    <div id="footer-wrapper">
      <div class="container row">
        <div class="footer-widgets-wrap">
          <div class="footer common-widget section" id="footer-sec1">
            <div class="widget HTML" data-version="2" id="HTML4">
              <div class="widget-title">
                <h3 class="title">
                  Recent Posts
                </h3>
              </div>
              <div class="widget-content">
                <ul class="custom-widget">
                                    <li class="item-0">
                    <a class="post-image-link" href="#">
                      <img class="post-thumb" alt="Healthy Spinach Pasta With Exotic Vegetables" src="img/hot2.jpg">
                    </a>
                    <div class="post-info">
                      <h2 class="post-title">
                        <a href="">Healthy Spinach Pasta With Exotic Vegetables</a>
                      </h2>
                      <div class="post-meta">
                        <span class="post-date">August 23, 2016</span>
                      </div>
                    </div>
                  </li>
                                    <li class="item-0">
                    <a class="post-image-link" href="#">
                      <img class="post-thumb" alt="Healthy Spinach Pasta With Exotic Vegetables" src="img/hot2.jpg">
                    </a>
                    <div class="post-info">
                      <h2 class="post-title">
                        <a href="">Healthy Spinach Pasta With Exotic Vegetables</a>
                      </h2>
                      <div class="post-meta">
                        <span class="post-date">August 23, 2016</span>
                      </div>
                    </div>
                  </li>
                                    <li class="item-0">
                    <a class="post-image-link" href="#">
                      <img class="post-thumb" alt="Healthy Spinach Pasta With Exotic Vegetables" src="img/hot2.jpg">
                    </a>
                    <div class="post-info">
                      <h2 class="post-title">
                        <a href="">Healthy Spinach Pasta With Exotic Vegetables</a>
                      </h2>
                      <div class="post-meta">
                        <span class="post-date">August 23, 2016</span>
                      </div>
                    </div>
                  </li>
                                  </ul>
              </div>
            </div>
          </div>
          <div class="footer common-widget section" id="footer-sec2" name="Section (Center)">
            <div class="widget Label" data-version="2" id="Label1">
              <div class="widget-title">
                <h3 class="title">
                  Categories
                </h3>
              </div>
              <div class="widget-content list-label">
                <ul>
                                    <li>
                    <a class="label-name" href="#">
                      Business
                      <span class="label-count">5</span>
                    </a>
                  </li>
                                    <li>
                    <a class="label-name" href="#">
                      Business
                      <span class="label-count">5</span>
                    </a>
                  </li>
                                    <li>
                    <a class="label-name" href="#">
                      Business
                      <span class="label-count">5</span>
                    </a>
                  </li>
                                  </ul>
              </div>
            </div>
            <div class="widget Label" data-version="2" id="Label2">
              <div class="widget-title">
                <h3 class="title">
                  Tags
                </h3>
              </div>
              <div class="widget-content cloud-label">
                <ul>
                                    <li>
                    <a class="label-name" href="search.php">
                      Beauty
                    </a>
                  </li>
                                    <li>
                    <a class="label-name" href="search.php">
                      Beauty
                    </a>
                  </li>
                                    <li>
                    <a class="label-name" href="search.php">
                      Beauty
                    </a>
                  </li>
                                  </ul>
              </div>
            </div>
          </div>
          <div class="footer common-widget section" id="footer-sec3">
            <div class="widget HTML" data-version="2" id="HTML3">
              <div class="widget-title">
                <h3 class="title">
                  Recent in Recipes
                </h3>
              </div>
              <div class="widget-content">
                <ul class="custom-widget">
                  <li class="item-0">
                    <a class="post-image-link" href="#">
                      <img class="post-thumb" alt="Frozen Blood and Sand Cocktail" src="img/hot1.jpg">
                    </a>
                    <div class="post-info">
                      <h2 class="post-title"><a href="#">Frozen
                          Blood and Sand Cocktail</a></h2>
                      <div class="post-meta"><span class="post-date">March 17, 2016</span></div>
                    </div>
                  </li>
                  <li class="item-1">
                    <a class="post-image-link" href="#">
                      <img class="post-thumb" alt="Girl Scout Cookie Samoa Shake" src="img/hot2.jpg">
                    </a>
                    <div class="post-info">
                      <h2 class="post-title">
                        <a href="">Girl Scout Cookie Samoa Shake</a>
                      </h2>
                      <div class="post-meta"><span class="post-date">March 17, 2016</span></div>
                    </div>
                  </li>
                  <li class="item-2">
                    <a class="post-image-link" href="#">
                      <img class="post-thumb" alt="Blueberry Cheesecake Protein Shake" src="img/hot3.jpg">
                    </a>
                    <div class="post-info">
                      <h2 class="post-title">
                        <a href="#">Blueberry Cheesecake Protein Shake</a>
                      </h2>
                      <div class="post-meta"><span class="post-date">March 17, 2016</span></div>
                    </div>
                  </li>
                </ul>
              </div>
            </div>
          </div>
        </div>
      </div>
      <div class="clearfix"></div>
      <div id="sub-footer-wrapper">
        <div class="container row">
          <div class="menu-footer section" id="menu-footer" name="Menu Footer">
            <div class="widget LinkList" data-version="2" id="LinkList76">
              <div class="widget-title">
                <h3 class="title">
                  Menu Footer Widget
                </h3>
              </div>
              <div class="widget-content">
                <ul>
                  <li><a href="/">Home</a></li>
                  <li><a href="">About</a></li>
                  <li><a href="">Contact Us</a></li>
                </ul>
              </div>
            </div>
          </div>
          <div class="copyright-area">Crafted with <i aria-hidden="true" class="fa fa-heart"
              style="color: red;margin:0 2px;"></i> by <a href="" id="mycontent">No One</a>
          </div>
        </div>
      </div>
    </div>
  </div>

  <script src="https://code.jquery.com/jquery-1.12.4.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/theia-sticky-sidebar@1.7.0/dist/theia-sticky-sidebar.min.js"></script>
  <script src="js/recipe.js"></script>
</body>

</html>